angular.module('avanteApp')

.controller('ApplicantController',function(ApplicantService,$scope,$state,$stateParams){

	$scope.user ={};
	$scope.items =[];
	$scope.register =function(){
		var users = {firstname: $scope.user.firstname,
			othername :$scope.user.othername,lastname:$scope.user.lastname,
			email:$scope.user.email,password:$scope.user.password};
			//console.log(users);
			ApplicantService.registerApplicant(users).then(function(data){
			 //ToasterService.toast(data);
//				window.localStorage.setItem('user_id',data.data.id);
$state.go('users');
})
		}

		ApplicantService.getAllUsers().then(function(data){
			//console.log(data.data.users);
			//ToasterService.toast(data);
			$scope.items =data.data.users;
		});
		
	})
.controller('UserDetailController',function(ApplicantService,$scope,$state,$stateParams){
	$scope.user={};
	
	ApplicantService.getAllUsersById($stateParams.id).then(function(data){
		
		$scope.user =data.data;
		//console.log($scope.user);
	});
})


    .controller('LoginController',function(ApplicantService,$scope,$state,$stateParams) {

        $scope.login = {};
        $scope.items = [];
        $scope.doLogin = function () {
            var loginuser = {email:$scope.login.email,password:$scope.login.password};
            //console.log(users);
            ApplicantService.postlogin(loginuser).then(function (data) {
                //ToasterService.toast(data);
                //console.log(data.data.email);
//				window.localStorage.setItem('user_id',data.data.id);
                $state.go('tab.dash');
            })
        }
    })
//added from tab

.controller('DashCtrl', function($scope) {})

.controller('ChatsCtrl', function($scope, Chats) {
  // With the new view caching in Ionic, Controllers are only called
  // when they are recreated or on app start, instead of every page change.
  // To listen for when this page is active (for example, to refresh data),
  // listen for the $ionicView.enter event:
  //
  //$scope.$on('$ionicView.enter', function(e) {
  //});
  
  $scope.chats = Chats.all();
  $scope.remove = function(chat) {
    Chats.remove(chat);
  }
})

.controller('ChatDetailCtrl', function($scope, $stateParams, Chats) {
  $scope.chat = Chats.get($stateParams.chatId);
})

.controller('AccountCtrl', function($scope) {
  $scope.settings = {
    enableFriends: true
  };
})

// .controller('buyAirtimeCtrl', ['$scope', '$stateParams', 
// function ($scope, $stateParams) {


// }])
   
// .controller('chooseNetworkCtrl', ['$scope', '$stateParams', 
// function ($scope, $stateParams) {


// }])
   
// .controller('mTNVTUCtrl', ['$scope', '$stateParams', 
// function ($scope, $stateParams) {


// }])
   
// .controller('gloVTUCtrl', ['$scope', '$stateParams', 
// function ($scope, $stateParams) {


// }])
   
// .controller('mobileVTUCtrl', ['$scope', '$stateParams', 
// function ($scope, $stateParams) {


// }])
   
// .controller('airtelVTUCtrl', ['$scope', '$stateParams', 
// function ($scope, $stateParams) {


// }])
   
// .controller('mTN100Ctrl', ['$scope', '$stateParams', 
// function ($scope, $stateParams) {


// }])
   
// .controller('mTN200Ctrl', ['$scope', '$stateParams', 
// function ($scope, $stateParams) {


// }])
   
// .controller('mTN400Ctrl', ['$scope', '$stateParams', 
// function ($scope, $stateParams) {


// }])
   
// .controller('mTN750Ctrl', ['$scope', '$stateParams', 
// function ($scope, $stateParams) {


// }])
   
// .controller('mTN1000Ctrl', ['$scope', '$stateParams', 
// function ($scope, $stateParams) {


// }])
   
// .controller('mTN1500Ctrl', ['$scope', '$stateParams', 
// function ($scope, $stateParams) {


// }])
   
// .controller('mTN2000Ctrl', ['$scope', '$stateParams', 
// function ($scope, $stateParams) {


// }])
   
// .controller('mTN3000Ctrl', ['$scope', '$stateParams', 
// function ($scope, $stateParams) {


// }])
   
// .controller('mTNTopupCtrl', ['$scope', '$stateParams', 
// function ($scope, $stateParams) {


// }])
   
// .controller('glo100Ctrl', ['$scope', '$stateParams', 
// function ($scope, $stateParams) {


// }])
   
// .controller('glo150Ctrl', ['$scope', '$stateParams', 
// function ($scope, $stateParams) {


// }])
   
// .controller('glo200Ctrl', ['$scope', '$stateParams', 
// function ($scope, $stateParams) {


// }])
   
// .controller('glo300Ctrl', ['$scope', '$stateParams', 
// function ($scope, $stateParams) {


// }])
   
// .controller('glo500Ctrl', ['$scope', '$stateParams', 
// function ($scope, $stateParams) {


// }])
   
// .controller('glo1000Ctrl', ['$scope', '$stateParams', 
// function ($scope, $stateParams) {


// }])
   
// .controller('glo3000Ctrl', ['$scope', '$stateParams', 
// function ($scope, $stateParams) {


// }])
   
// .controller('gloTopupCtrl', ['$scope', '$stateParams',
// function ($scope, $stateParams) {


// }])
   
// .controller('mobile100Ctrl', ['$scope', '$stateParams', 
// function ($scope, $stateParams) {


// }])
   
// .controller('mobile200Ctrl', ['$scope', '$stateParams', 
// function ($scope, $stateParams) {


// }])
   
// .controller('mobile500Ctrl', ['$scope', '$stateParams', 
// function ($scope, $stateParams) {


// }])
   
// .controller('mobile1000Ctrl', ['$scope', '$stateParams', 
// function ($scope, $stateParams) {


// }])
   
// .controller('mobileTopupCtrl', ['$scope', '$stateParams', 
// function ($scope, $stateParams) {


// }])
   
// .controller('airtel100Ctrl', ['$scope', '$stateParams', 
// function ($scope, $stateParams) {


// }])
   
// .controller('airtel200Ctrl', ['$scope', '$stateParams', 
// function ($scope, $stateParams) {


// }])
   
// .controller('airtel500Ctrl', ['$scope', '$stateParams', 
// function ($scope, $stateParams) {


// }])
   
// .controller('airtel1000Ctrl', ['$scope', '$stateParams',
// function ($scope, $stateParams) {


// }])
   
// .controller('airtelTopupCtrl', ['$scope', '$stateParams', 
// function ($scope, $stateParams) {


// }]);

