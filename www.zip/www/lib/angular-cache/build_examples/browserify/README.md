Running `browserify app.js > bundle.js` in this directory will produce `bundle.js`
