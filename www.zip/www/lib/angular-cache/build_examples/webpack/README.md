Running `webpack` in this directory will produce `bundle.js`
