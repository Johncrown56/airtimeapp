angular.module('app.routes', [])

.config(function($stateProvider, $urlRouterProvider) {

  // Ionic uses AngularUI Router which uses the concept of states
  // Learn more here: https://github.com/angular-ui/ui-router
  // Set up the various states which the app can be in.
  // Each state's controller can be found in controllers.js
  $stateProvider
    

      .state('buyAirtime', {
    url: '/page1',
    templateUrl: 'templates/buyAirtime.html',
    controller: 'buyAirtimeCtrl'
  })

  .state('chooseNetwork', {
    url: '/page2',
    templateUrl: 'templates/chooseNetwork.html',
    controller: 'chooseNetworkCtrl'
  })

  .state('mTNVTU', {
    url: '/page3',
    templateUrl: 'templates/mTNVTU.html',
    controller: 'mTNVTUCtrl'
  })

  .state('gloVTU', {
    url: '/page4',
    templateUrl: 'templates/gloVTU.html',
    controller: 'gloVTUCtrl'
  })

  .state('mobileVTU', {
    url: '/page5',
    templateUrl: 'templates/mobileVTU.html',
    controller: 'mobileVTUCtrl'
  })

  .state('airtelVTU', {
    url: '/page6',
    templateUrl: 'templates/airtelVTU.html',
    controller: 'airtelVTUCtrl'
  })

  .state('mTN100', {
    url: '/page7',
    templateUrl: 'templates/mTN100.html',
    controller: 'mTN100Ctrl'
  })

  .state('mTN200', {
    url: '/page8',
    templateUrl: 'templates/mTN200.html',
    controller: 'mTN200Ctrl'
  })

  .state('mTN400', {
    url: '/page9',
    templateUrl: 'templates/mTN400.html',
    controller: 'mTN400Ctrl'
  })

  .state('mTN750', {
    url: '/page10',
    templateUrl: 'templates/mTN750.html',
    controller: 'mTN750Ctrl'
  })

  .state('mTN1000', {
    url: '/page11',
    templateUrl: 'templates/mTN1000.html',
    controller: 'mTN1000Ctrl'
  })

  .state('mTN1500', {
    url: '/page12',
    templateUrl: 'templates/mTN1500.html',
    controller: 'mTN1500Ctrl'
  })

  .state('mTN2000', {
    url: '/page13',
    templateUrl: 'templates/mTN2000.html',
    controller: 'mTN2000Ctrl'
  })

  .state('mTN3000', {
    url: '/page14',
    templateUrl: 'templates/mTN3000.html',
    controller: 'mTN3000Ctrl'
  })

  .state('mTNTopup', {
    url: '/page35',
    templateUrl: 'templates/mTNTopup.html',
    controller: 'mTNTopupCtrl'
  })

  .state('glo100', {
    url: '/page15',
    templateUrl: 'templates/glo100.html',
    controller: 'glo100Ctrl'
  })

  .state('glo150', {
    url: '/page16',
    templateUrl: 'templates/glo150.html',
    controller: 'glo150Ctrl'
  })

  .state('glo200', {
    url: '/page17',
    templateUrl: 'templates/glo200.html',
    controller: 'glo200Ctrl'
  })

  .state('glo300', {
    url: '/page18',
    templateUrl: 'templates/glo300.html',
    controller: 'glo300Ctrl'
  })

  .state('glo500', {
    url: '/page19',
    templateUrl: 'templates/glo500.html',
    controller: 'glo500Ctrl'
  })

  .state('glo1000', {
    url: '/page21',
    templateUrl: 'templates/glo1000.html',
    controller: 'glo1000Ctrl'
  })

  .state('glo3000', {
    url: '/page22',
    templateUrl: 'templates/glo3000.html',
    controller: 'glo3000Ctrl'
  })

  .state('gloTopup', {
    url: '/page23',
    templateUrl: 'templates/gloTopup.html',
    controller: 'gloTopupCtrl'
  })

  .state('mobile100', {
    url: '/page24',
    templateUrl: 'templates/mobile100.html',
    controller: 'mobile100Ctrl'
  })

  .state('mobile200', {
    url: '/page25',
    templateUrl: 'templates/mobile200.html',
    controller: 'mobile200Ctrl'
  })

  .state('mobile500', {
    url: '/page26',
    templateUrl: 'templates/mobile500.html',
    controller: 'mobile500Ctrl'
  })

  .state('mobile1000', {
    url: '/page27',
    templateUrl: 'templates/mobile1000.html',
    controller: 'mobile1000Ctrl'
  })

  .state('mobileTopup', {
    url: '/page28',
    templateUrl: 'templates/mobileTopup.html',
    controller: 'mobileTopupCtrl'
  })

  .state('airtel100', {
    url: '/page29',
    templateUrl: 'templates/airtel100.html',
    controller: 'airtel100Ctrl'
  })

  .state('airtel200', {
    url: '/page30',
    templateUrl: 'templates/airtel200.html',
    controller: 'airtel200Ctrl'
  })

  .state('airtel500', {
    url: '/page34',
    templateUrl: 'templates/airtel500.html',
    controller: 'airtel500Ctrl'
  })

  .state('airtel1000', {
    url: '/page31',
    templateUrl: 'templates/airtel1000.html',
    controller: 'airtel1000Ctrl'
  })

  .state('airtelTopup', {
    url: '/page32',
    templateUrl: 'templates/airtelTopup.html',
    controller: 'airtelTopupCtrl'
  })


$urlRouterProvider.otherwise('/page1')


});