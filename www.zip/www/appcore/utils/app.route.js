angular.module('avanteApp')

.config(function($stateProvider, $urlRouterProvider, $raveProvider) {
	
	$stateProvider

	

	.state('login', {
		url: '/login',
		templateUrl: 'views/auth/login.html',
		controller:'AuthController'
	})

        .state('forgotpass', {
            url: '/forgotpass',
            templateUrl: 'views/auth/forgotpass.html',
            controller:'ForgotPassController'
        })

        .state('resetpass', {
            url: '/resetpass',
            templateUrl: 'views/auth/resetpass.html',
            controller:'ResetPassController'
        })

        .state('landing', {
		url: '/landing',
		templateUrl: 'views/landing.html',
		controller:'LandingCtrl'
	})
	.state('reg', {
		url: '/reg',
		templateUrl: 'views/auth/register.html',
		controller:"AuthRegController"
	})
	.state('app', {
		url: '/app',
		abstract: true,
		templateUrl: 'views/sidemenu.html',
		controller:"AuthController"
	})
	.state('tab', {
		url: '/tab',
		abstract: true,
		templateUrl: 'views/tab.html'
	})


	.state('app.listing', {
		url: '/listing',
		views: {
			'menuContent': {
				templateUrl:'views/coreviews/listing.html',
				controller:''
			}
		}
	})

.state('app.buy', {
		url: '/buy',
		views: {
			'menuContent': {
				templateUrl:'views/coreviews/buy.html',
				controller:''
			}
		}
	})
	.state('app.transactions', {
		url: '/transactions',
		views: {
			'menuContent': {
				templateUrl:'views/coreviews/transactions.html',
				controller:''
			}
		}
	})

	.state('app.transactionsBreakDown', {
		url: '/transactionsBreakDown/:subMerchantId/:transType/:submerchantName',
		views: {
			'menuContent': {
				templateUrl:'views/coreviews/transactionsBreakDown.html',
				controller:'TransactionsController'
			}
		}
	})

	.state('app.voucherTrans', {
		url: '/voucherTrans/:submerchantName',
		views: {
			'menuContent': {
				templateUrl:'views/coreviews/voucherTrans.html',
				controller:'VoucherDataController'
			}
		}
	})

.state('app.voucher', {
		url: '/voucher',
		views: {
			'menuContent': {
				templateUrl:'views/coreviews/voucher.html',
				controller:'VoucherSetupController'
			}
		}
	})

	.state('app.qr', {
		url: '/qr',
		views: {
			'menuContent': {
				templateUrl:'views/coreviews/qr.html',
				controller:'QrController'
			}
		}
	})
	.state('app.about', {
		url: '/about',
		views: {
			'menuContent': {
				templateUrl:'views/coreviews/about.html',
				controller:''
			}
		}
	})


	.state('app.help', {
		url: '/help',
		views: {
			'menuContent': {
				templateUrl:'views/coreviews/help.html',
				controller:'HelpController'
			}
		}
	})
.state('app.faq', {
		url: '/FAQ',
		views: {
			'menuContent': {
				templateUrl:'views/coreviews/FAQ.html',
				controller:'FaqController'
			}
		}
	})

	.state('app.profile', {
		url: '/profile',
		views: {
			'menuContent': {
				templateUrl: 'views/coreviews/profile.html',
				controller:"ProfileController"
			}
		}
	})

	// john  code starts


	.state('app.buyAirtime', {
		url: '/buyAirtime',
		views: {
			'menuContent': {
		templateUrl: 'views/coreviews/buyAirtime.html',
		controller: 'buyAirtimeCtrl'
			}
		}
	  })
	
	  .state('app.chooseNetwork', {
		url: '/chooseNetwork',
		views: {
			'menuContent': {
		templateUrl: 'views/coreviews/chooseNetwork.html',
		controller: 'chooseNetworkCtrl'
			}
		}
	  })
	
	  .state('app.mTNVTU', {
		url: '/mTNVTU',
		views: {
			'menuContent': {
		templateUrl: 'views/coreviews/mTNVTU.html',
		controller: 'mTNVTUCtrl'
			}}
	  })
	
	  .state('app.gloVTU', {
		url: '/gloVTU',
		views: {
			'menuContent': {
		templateUrl: 'views/coreviews/gloVTU.html',
		controller: 'gloVTUCtrl'
			}
		}
	  })
	
	  .state('app.mobileVTU', {
		url: '/mobileVTU',
		views: {
			'menuContent': {
		templateUrl: 'views/coreviews/mobileVTU.html',
		controller: 'mobileVTUCtrl'
			}
		}
	  })
	
	  .state('app.airtelVTU', {
		url: '/airtelVTU',
		views: {
			'menuContent': {
		templateUrl: 'views/coreviews/airtelVTU.html',
		controller: 'airtelVTUCtrl'
			}
		}
	  })
	
	  .state('app.mTN100', {
		url: '/mTN100',
		views: {
			'menuContent': {
		templateUrl: 'views/coreviews/mTN100.html',
		controller: 'mTN100Ctrl'
			}
		}
	  })
	
	  .state('app.mTN200', {
		url: '/mTN200',
		views: {
			'menuContent': {
		templateUrl: 'views/coreviews/mTN200.html',
		controller: 'mTN200Ctrl'
			}
		}
	  })
	
	  .state('app.mTN400', {
		url: '/mTN400',
		views: {
			'menuContent': {
		templateUrl: 'views/coreviews/mTN400.html',
		controller: 'mTN400Ctrl'
			}
		}
	  })
	
	  .state('app.mTN750', {
		url: '/mTN750',
		views: {
			'menuContent': {
		templateUrl: 'views/coreviews/mTN750.html',
		controller: 'mTN750Ctrl'
			}
		}
	  })
	
	  .state('app.mTN1000', {
		url: '/mTN1000',
		views: {
			'menuContent': {
		templateUrl: 'views/coreviews/mTN1000.html',
		controller: 'mTN1000Ctrl'
			}
		}
	  })
	
	  .state('app.mTN1500', {
		url: '/mTN1500',
		views: {
			'menuContent': {
		templateUrl: 'views/coreviews/mTN1500.html',
		controller: 'mTN1500Ctrl'
			}
		}
	  })
	
	  .state('app.mTN2000', {
		url: '/mTN2000',
		views: {
			'menuContent': {
		templateUrl: 'views/coreviews/mTN2000.html',
		controller: 'mTN2000Ctrl'
			}
		}
	  })
	
	  .state('app.mTN3000', {
		url: '/mTN3000',
		views: {
			'menuContent': {
		templateUrl: 'views/coreviews/mTN3000.html',
		controller: 'mTN3000Ctrl'
			}
		}
	  })
	
	  .state('app.mTNTopup', {
		url: '/mTNTopup',
		views: {
			'menuContent': {
		templateUrl: 'views/coreviews/mTNTopup.html',
		controller: 'mTNTopupCtrl'
			}
		}
	  })
	
	  .state('app.glo100', {
		url: '/glo100',
		views: {
			'menuContent': {
		templateUrl: 'views/coreviews/glo100.html',
		controller: 'glo100Ctrl'
			}
		}
	  })
	
	  .state('app.glo150', {
		url: '/glo150',
		views: {
			'menuContent': {
		templateUrl: 'views/coreviews/glo150.html',
		controller: 'glo150Ctrl'
			}
		}
	  })
	
	  .state('app.glo200', {
		url: '/glo200',
		views: {
			'menuContent': {
		templateUrl: 'views/coreviews/glo200.html',
		controller: 'glo200Ctrl'
			}
		}
	  })
	
	  .state('app.glo300', {
		url: '/glo300',
		views: {
			'menuContent': {
		templateUrl: 'views/coreviews/glo300.html',
		controller: 'glo300Ctrl'
			}
		}
	  })
	
	  .state('app.glo500', {
		url: '/glo500',
		views: {
			'menuContent': {
		templateUrl: 'views/coreviews/glo500.html',
		controller: 'glo500Ctrl'
			}
		}
	  })
	
	  .state('app.glo1000', {
		url: '/glo1000',
		views: {
			'menuContent': {
		templateUrl: 'views/coreviews/glo1000.html',
		controller: 'glo1000Ctrl'
			}
		}
	  })
	
	  .state('app.glo3000', {
		url: '/glo3000',
		views: {
			'menuContent': {
		templateUrl: 'views/coreviews/glo3000.html',
		controller: 'glo3000Ctrl'
			}
		}
	  })
	
	  .state('app.gloTopup', {
		url: '/gloTopup',
		views: {
			'menuContent': {
		templateUrl: 'views/coreviews/gloTopup.html',
		controller: 'gloTopupCtrl'
			}
		}
	  })
	
	  .state('app.mobile100', {
		url: '/mobile100',
		views: {
			'menuContent': {
		templateUrl: 'views/coreviews/mobile100.html',
		controller: 'mobile100Ctrl'
			}
		}
	  })
	
	  .state('app.mobile200', {
		url: '/mobile200',
		views: {
			'menuContent': {
		templateUrl: 'views/coreviews/mobile200.html',
		controller: 'mobile200Ctrl'
			}
		}
	  })
	
	  .state('app.mobile500', {
		url: '/mobile500',
		views: {
			'menuContent': {
		templateUrl: 'views/coreviews/mobile500.html',
		controller: 'mobile500Ctrl'
			}
		}
	  })
	
	  .state('app.mobile1000', {
		url: '/mobile1000',
		views: {
			'menuContent': {
		templateUrl: 'views/coreviews/mobile1000.html',
		controller: 'mobile1000Ctrl'
			}
		}
	  })
	
	  .state('app.mobileTopup', {
		url: '/mobileTopup',
		views: {
			'menuContent': {
		templateUrl: 'views/coreviews/mobileTopup.html',
		controller: 'mobileTopupCtrl'
			}
		}
	  })
	
	  .state('app.airtel100', {
		url: '/airtel100',
		views: {
			'menuContent': {
		templateUrl: 'views/coreviews/airtel100.html',
		controller: 'airtel100Ctrl'
			}
		}
	  })
	
	  .state('app.airtel200', {
		url: '/airtel200',
		views: {
			'menuContent': {
		templateUrl: 'views/coreviews/airtel200.html',
		controller: 'airtel200Ctrl'
			}
		}
	  })
	
	  .state('app.airtel500', {
		url: '/airtel500',
		views: {
			'menuContent': {
		templateUrl: 'views/coreviews/airtel500.html',
		controller: 'airtel500Ctrl'
			}
		}
	  })
	
	  .state('app.airtel1000', {
		url: '/airtel1000',
		views: {
			'menuContent': {
		templateUrl: 'views/coreviews/airtel1000.html',
		controller: 'airtel1000Ctrl'
			}
		}
	  })
	
	  .state('app.airtelTopup', {
		url: '/airtelTopup',
		views: {
			'menuContent': {
		templateUrl: 'views/coreviews/airtelTopup.html',
		controller: 'airtelTopupCtrl'
			}
		}
		})
		
		.state('app.allstores', {
			url: '/allstores',
			views: {
				'menuContent': {
					templateUrl:'views/coreviews/allstores.html',
					controller:'allStoresCtrl'
				}
			}
		})
	

		.state('app.airtimesummary', {
			url: '/airtimesummary',
			views: {
				'menuContent': {
					templateUrl:'views/coreviews/airtimesummary.html',
					controller:'airtimesummaryCtrl'
				}
			}
		})

		.state('app.airtimecategory', {
			url: '/airtimecategory',
			views: {
				'menuContent': {
					templateUrl:'views/coreviews/airtimecategory.html',
					controller:'airtimecategoryCtrl'
				}
			}
		})

		.state('app.airtimeform', {
			url: '/airtimeform',
			views: {
				'menuContent': {
					templateUrl:'views/coreviews/airtimeform.html',
					controller:'airtimeformCtrl'
				}
			}
		})

		.state('app.airtimeotherform', {
			url: '/airtimeotherform',
			views: {
				'menuContent': {
					templateUrl:'views/coreviews/airtimeotherform.html',
					controller:'airtimeotherformCtrl'
				}
			}
		})

		$urlRouterProvider.otherwise('/app/listing')
})




		
