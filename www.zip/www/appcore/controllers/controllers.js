angular.module('avanteApp')

    // Authentication Controller
    .controller('AuthController', ['AuthService', '$scope', '$ionicLoading', '$state',
        '$ionicPopup', '$timeout', 'InternetMonitor', '$ionicHistory', '$cordovaSQLite', 'localStorageService','MerchantService', function (AuthService, $scope, $ionicLoading, $state,
            $ionicPopup, $timeout, InternetMonitor, $ionicHistory, $cordovaSQLite, localStorageService,MerchantService) {
            // check if the user has previously logged in
            if (AuthService.getLoggedInUserToken() == null) {
                $state.go('login');
            }
            else {
                $state.go("app.listing");
            }
            $scope.init = function () {
                if (AuthService.getLoggedInUserToken() == null) {
                    $state.go('login');
                } else {
                    $state.go("app.listing");
                }
            }
            $scope.login = {};
            // do an error if Login Fails
            var error = function (error) {
                $ionicLoading.hide();
               // //console.log(error);
                $scope.error = error == null ? error.data.statusText : 'The internet is disconnected on your device.';
                $scope.title = error == null ? "Invalid Login" : 'Internet Disconnected';
                var errorPopup = $ionicPopup.show({
                    templateUrl: 'views/common/erorr.html',
                    title: $scope.title,
                    scope: $scope,
                    buttons: [
                        { text: 'Ok' }
                    ]
                });


                $timeout(function () {
                    errorPopup.close(); //close the popup after 3 seconds for some reason
                }, 4000);
            }

            // do a success if login pass, set local storage 
            var success = function (response) {
                $ionicLoading.hide();
               // //console.log(response);
                $ionicLoading.hide();
                if (response.data.status == 0) {
                    $scope.error = 'The internet is disconnected on your device.';//response.data.message;

                    var errorPopup = $ionicPopup.show({
                        templateUrl: 'views/common/erorr.html',
                        title: 'Error',
                        scope: $scope,
                        buttons: [
                            { text: 'Ok' }
                        ]
                    });


                    $timeout(function () {
                        errorPopup.close(); //close the popup after 3 seconds for some reason
                    }, 4000);

                    return;
                }

                if (response.data.error == true) {
                    $scope.error = response.data.message;//'The internet is disconnected on your device.';//response.data.message;

                    var errorPopup = $ionicPopup.show({
                        templateUrl: 'views/common/erorr.html',
                        title: 'Error',
                        scope: $scope,
                        buttons: [
                            { text: 'Ok' }
                        ]
                    });


                    $timeout(function () {
                        errorPopup.close(); //close the popup after 3 seconds for some reason
                    }, 4000);

                    return;
                }
                localStorageService.set('user_log', JSON.stringify(response.data))
                localStorageService.set('user_no', JSON.stringify($scope.login.userno))
                AuthService.setLoginUserIdToken(response.data.id);
                AuthService.setMerchantDbToken(response.data.merchantDb);
                AuthService.setSerialNoToken(response.data.serialNo);

               // //console.log(response.data);
                ////console.log(AuthService.getSerialNoToken());
                if (response.data.default == "1") {

                    ////console.log(response.data.default);
                    $state.go("resetpass");
                }
                else {
                    $ionicHistory.clearCache().then(function () { $state.go('app.listing', {}, { reload: true }) })
                }


            }
            
             
             var success1 = function (response) {
                //$scope.wallets = response.data;
                console.log(response.data);
                localStorageService.set('submerchantData', JSON.stringify(response.data))
                console.log(localStorageService.get('submerchantData'));
            }
            // do login 
            $scope.login = function () {
                $ionicLoading.show({
                    templateUrl: "views/common/wait.html"
                });
                window.localStorage.clear();
                AuthService.loginUser({ userno: $scope.login.userno, password: $scope.login.password })
                    .then(success, error);
             MerchantService.MerchantList({}).then(success1, error);
            }
            // do logout and clear all data return user to login page
            $scope.logOut = function () {
                AuthService.removeUserToken();
                AuthService.removeSerialNoToken();
                AuthService.removeMerchantDbToken();
                window.localStorage.clear();
                ////console.log("Got here");
                $state.go('login');
                // $window.close()
                // ionic.Platform.exitApp()
            }

        }])
    // Gate keeper 
    .controller('LandingCtrl', ['AuthService', '$scope', '$state',
        function (AuthService, $scope, $state) {
            $scope.init = function () {
                if (AuthService.getLoggedInUserToken() == null) {
                    $state.go('login');
                } else {
                    $state.go("app.listing");
                }
            }
        }])

    // Forgot Password Controller
    .controller('ForgotPassController', ['AuthService', '$scope', '$ionicLoading', '$state', '$ionicPopup', '$timeout',
        function (AuthService, $scope, $ionicLoading, $state, $ionicPopup, $timeout) {

            $scope.helper = {};
            var registerData = { userid: $scope.helper.userid, email: $scope.helper.email };

            var error = function (error) {
                $ionicLoading.hide();
                ////console.log(error);
                $ionicLoading.hide();

                $scope.error = error.data.statusText;

                var errorPopup = $ionicPopup.show({
                    templateUrl: 'views/common/erorr.html',
                    title: 'Error',
                    scope: $scope,
                    buttons: [
                        { text: 'Ok' }
                    ]
                });

                $timeout(function () {
                    errorPopup.close(); //close the popup after 3 seconds for some reason
                }, 4000);
            }

            var success = function (response) {

                $ionicLoading.hide();
                ////console.log(response.data.message);
                $ionicLoading.hide();
                if (response.data.error == true) {
                    $scope.error = response.data.message;

                    var errorPopup = $ionicPopup.show({
                        templateUrl: 'views/common/erorr.html',
                        title: 'Error',
                        scope: $scope,
                        buttons: [
                            { text: 'Ok' }
                        ]
                    });

                    $timeout(function () { errorPopup.close(); }, 4000);
                    //return;
                } else {
                    $scope.successmsg = response.data.message;

                    var successPopup = $ionicPopup.show({
                        templateUrl: 'views/common/success.html',
                        title: 'Information',
                        scope: $scope,
                        buttons: [
                            { text: 'Ok' }
                        ]
                    });
                    $timeout(function () { successPopup.close(); }, 10000);

                    $state.go("login");
                }

            }

            $scope.sendhelp = function () {

                $ionicLoading.show({
                    templateUrl: "views/common/wait.html"
                });
                AuthService.forgotPass({ userid: $scope.helper.userid, email: $scope.helper.email })
                    .then(success, error);
            }

        }])

    // Reset Password Controller
    .controller('ResetPassController', ['AuthService', '$scope', '$ionicLoading', '$state', '$ionicPopup', '$timeout', 'localStorageService', '$ionicHistory',
        function (AuthService, $scope, $ionicLoading, $state, $ionicPopup, $timeout, localStorageService, $ionicHistory) {
            ////console.log(AuthService.getSerialNoToken());
            $scope.helper = {};
            $scope.userData = JSON.parse(localStorageService.get('user_log'))
            $scope.userNo = JSON.parse(localStorageService.get('user_no'))

            var registerData = { userid: AuthService.getSerialNoToken(), password: $scope.helper.password1, email: $scope.userData.email };

            var error = function (error) {
                $ionicLoading.hide();
                ////console.log(error);
                $ionicLoading.hide();

                $scope.error = error.data.statusText;

                var errorPopup = $ionicPopup.show({
                    templateUrl: 'views/common/erorr.html',
                    title: 'Error',
                    scope: $scope,
                    buttons: [
                        { text: 'Ok' }
                    ]
                });

                $timeout(function () {
                    errorPopup.close(); //close the popup after 3 seconds for some reason
                }, 4000);
            }

            var success = function (response) {
                ////console.log(response.data.message);
                $ionicLoading.hide();
                if (response.data.error == true) {
                    $scope.error = response.data.message;

                    var errorPopup = $ionicPopup.show({
                        templateUrl: 'views/common/erorr.html',
                        title: 'Error',
                        scope: $scope,
                        buttons: [
                            { text: 'Ok' }
                        ]
                    });

                    $timeout(function () { errorPopup.close(); }, 4000);
                    //return;
                } else {
                    $scope.successmsg = response.data.message;

                    var successPopup = $ionicPopup.show({
                        templateUrl: 'views/common/success.html',
                        title: 'Information',
                        scope: $scope,
                        buttons: [
                            { text: 'Ok' }
                        ]
                    });
                    $timeout(function () { successPopup.close(); }, 4000);

                    $ionicHistory.clearCache().then(function () { $state.go('app.listing', {}, { reload: true }) })

                }

            }

            $scope.doReset = function () {
                // ////console.log($scope.userNo);
                $ionicLoading.show({
                    templateUrl: "views/common/wait.html"
                });
                if ($scope.helper.password1 == $scope.helper.password2) {

                    AuthService.resetPass({ userid: $scope.userNo, password: $scope.helper.password1, email: $scope.userData.email })
                        .then(success, error);

                }
                else {

                    $ionicLoading.hide();
                    $scope.error = "password does not match";

                    var errorPopup = $ionicPopup.show({
                        templateUrl: 'views/common/erorr.html',
                        title: 'Error',
                        scope: $scope,
                        buttons: [
                            { text: 'Ok' }
                        ]
                    });

                    $timeout(function () {
                        errorPopup.close(); //close the popup after 3 seconds for some reason
                    }, 4000);
                }
            }

        }])



    .controller('QrController', ['AuthService', '$scope', '$ionicLoading', function (AuthService, $scope, $ionicLoading) {

        //////console.log(response.data.serialNo);
        //////console.log(AuthService.getSerialNoToken());
        $ionicLoading.show({
            templateUrl: "views/common/wait.html"
        });
        $scope.ser = AuthService.getSerialNoToken()
        //console.log($scope.ser);
        $ionicLoading.hide();
        // //console.log(localStorage.getItem(Constants.API.userIdToken));

    }]
    )
    .controller('FaqController', ['AuthService', '$scope', '$ionicLoading', function (AuthService, $scope, $ionicLoading) {

        ////console.log(response.data.serialNo);
        ////console.log(AuthService.getSerialNoToken());
        $ionicLoading.show({
            templateUrl: "views/common/wait.html"
        });
        // $scope.ser = AuthService.getSerialNoToken()
        ////console.log($scope.ser);
        $ionicLoading.hide();

        $scope.titles = ["What is MoLoyal loyalty App? ", "Where can I use MoLoyal? ", "Which devices support MoLoyal loyalty app? ",
            "Are there any hidden costs when using the MoLoyal loyalty app? ", "How do I update my personal information?",
            "What are Points?", "What do you mean by Rewards?", "How do I find out about current Rewards schemes?", "Where are my rewards and how do I redeem them?",
            "I forgot to swipe my card, can I claim my points?", "What do I do if my MoLoyal/Merchant vouchers have expired?"];
        $scope.content = ["The MoLoyal loyalty App is a loyalty programme through which individuals will be offered the opportunity to earn reward points through repeat purchases from any of MoLoyal’s coalition outlets.",
            "The MoLoyal loyalty app can be used at any store or for any service participating in the coalition programme",
            "The MoLoyal loyalty app is available to download on Android. It will be available on iOS mobile devices in the near future.",
            "The MoLoyal loyalty app is completely free to use. In fact, we work hard to reward you for every Kobo you spend and by negotiating exclusive MoLoyal deals with our merchants.",
            "It is easy to change your personal details online, here's how to do it: Log in with your MoLoyal username and password. Next, click on 'My Profile' and select ‘Update Profile. Follow the instructions to update your personal details and once you have finished, click 'Update' at the bottom of the page. Your email and mobile number must be unique to your account and if changing these contact details, you will be taken through a simple authentication journey to verify your changes.",
            "At most merchants, you can earn Points on every transaction. Collect 10000 points for every 10000 naira spent in any store or online. Go to the Transactions section of your app to see how many points you have earned from each merchant.",
            "Different retailers and outlets run their own Rewards schemes.", "Go to the list of participating merchants and select the particular merchants whose reward scheme you are interested in to see details.",
            "Select the reward you would like to redeem, and just like paying, present the QR code to the cashier to scan at the till",
            "Some companies participating in the MoLoyal programme will credit points if you have forgotten to swipe, usually within a limited time period.",
            "Once you have exchanged your points for MoLoyal vouchers they can not be added back onto your account. All vouchers have the expiry date printed on them and collectors should use them before this date."];
        $scope.groups = [];
        for (var i = 0; i < $scope.titles.length; i++) {
            $scope.groups[i] = {
                title: $scope.titles[i],
                content: $scope.content[i]
            };

        }

        /*
         * if given group is the selected group, deselect it
         * else, select the given group
         */
        $scope.toggleGroup = function (group) {
            if ($scope.isGroupShown(group)) {
                $scope.shownGroup = null;
            } else {
                $scope.shownGroup = group;
            }
        };
        $scope.isGroupShown = function (group) {
            return $scope.shownGroup === group;
        };
        //console.log($scope.groups);

    }]
    )
    .controller('HelpController', ['AuthService', 'mailService', '$scope', '$ionicLoading', '$ionicPopup', 'localStorageService', '$state', '$timeout', function (AuthService, mailService, $scope, $ionicLoading, $ionicPopup, localStorageService, $state, $timeout) {


        $scope.userData = JSON.parse(localStorageService.get('user_log'));
        $scope.userNo = JSON.parse(localStorageService.get('user_no'))
        $scope.ser = AuthService.getSerialNoToken();
        $scope.Message = {};
        $scope.userName = $scope.userData.firstname + " " + $scope.userData.lastname;
        //console.log($scope.userData);
       
        var error = function (error) {
            $ionicLoading.hide();
            console.log(error);
            $scope.error = error == null ? error.data.statusText : 'The internet is disconnected on your device.';
            $scope.title = error == null ? "Invalid Login" : 'Internet Disconnected';
            var errorPopup = $ionicPopup.show({
                templateUrl: 'views/common/success.html',
                title: $scope.title,
                scope: $scope,
                buttons: [
                    { text: 'Ok' }
                ]
            });



            $timeout(function () {
                errorPopup.close(); //close the popup after 3 seconds for some reason
            }, 4000);

            return;
        }

        // do success function
        // do a success if login pass, set local storage 
        var success = function (response) {
            //console.log(response);
            if (response.data.error == false) {
                $scope.error = response.data.message;

                var errorPopup = $ionicPopup.show({
                    templateUrl: 'views/common/erorr.html',
                    title: 'Info',
                    scope: $scope,
                    buttons: [
                        { text: 'Ok' }
                    ]
                });

            $ionicLoading.hide();

                $timeout(function () {
                    errorPopup.close(); //close the popup after 3 seconds for some reason
                }, 4000);
                $state.go("app.listing");

                return;
            }
        }

        $scope.sendMail = function () {
console.log($scope.userData.email);
            $ionicLoading.show({
                templateUrl: "views/common/wait.html"
            });
            mailService.sendMail({ userid: $scope.ser, email: $scope.userData.email, phoneno: $scope.userNo, message: $scope.Message.comment, title: $scope.Message.title })
                .then(success, error);
        }

    }]
    )
    .controller("DoughnutCtrl", ['AuthService', 'GraphService', '$scope', '$ionicLoading', 'InternetMonitor',
        'localStorageService',
        function (AuthService, GraphService, $scope, $ionicLoading, InternetMonitor, localStorageService) {
            $scope.labels = ["Accruals", "Airtime"];
            $scope.data = [];
            $ionicLoading.show({
                templateUrl: "views/common/wait.html"
            });
            // do error function
            var error = function (error) {
                $ionicLoading.hide();
                $scope.data = localStorageService.get('GraphData');
                //console.log($scope.data);
            }
            // do success function
            var success = function (response) {
                $ionicLoading.hide();
                $scope.data = [response.data.accrue.AccuralTrans, response.data.redeem.RedemTrans];
                localStorageService.remove('GraphData');
                localStorageService.set('GraphData', JSON.stringify($scope.data));
            }

            // avoid caching function
            function getMeData() {
                $scope.ser = GraphService.getGraphData({ id: AuthService.getLoggedInUserToken(), dbname: AuthService.getMerchantDbToken(), serialnum: AuthService.getSerialNoToken() })
                    .then(success, error);
            }

            // refreash graph every few seconds
            setInterval(function () {
                getMeData();
            }, 5000);

        }])



    .controller('TableCtrl', function ($scope, $stateParams, $http, $location, $ionicModal, $filter, localStorageService, $ionicLoading
        , InternetMonitor, TransactionService, AuthService, $timeout, ionicMaterialMotion, ionicMaterialInk) {
        $scope.transactions = [];
        $scope.subMerchant = [];
        $scope.countTransaction;
        $scope.tabValues = [];
        var tabValuesHeader = '{ "values" : [';

        $ionicLoading.show({
            templateUrl: "views/common/wait.html"
        });

        var error = function (error) {
            $ionicLoading.hide();
            // //console.log(error.data);
            //$scope.error = error.data.text;

            var errorPopup = $ionicPopup.show({
                templateUrl: 'views/common/erorr.html',
                title: 'Error',
                scope: $scope,
                buttons: [
                    { text: 'Ok' }
                ]
            });


            $timeout(function () {
                errorPopup.close(); //close the popup after 3 seconds for some reason
            }, 1000);
        }


        var success = function (response) {
            //console.log('trans', response.data.transactions);
            $ionicLoading.hide();
            $scope.transactions = response.data.transactions;
            localStorageService.remove('user_transaction');
            localStorageService.set('user_transaction', JSON.stringify(response.data.transactions));
            $scope.countTransaction = Object.keys($scope.transactions).length
            getSubMerchants();
            //console.log($scope.transactions);

        }
        function getSubMerchants() {
            $scope.subMerchant = {}
            for (var i = 0; i < $scope.countTransaction; i++) {
                $scope.subMerchant[$scope.transactions[i].submerchantId] = $scope.transactions[i];
            }
            //console.log(_.keys($scope.subMerchant));
            getTotalAccurals(201501);

        }

        if (InternetMonitor.isOnline()) {
            TransactionService.getUserTransaction({
                id: AuthService.getLoggedInUserToken(),
                dbname: AuthService.getMerchantDbToken(), serialnum: AuthService.getSerialNoToken()
            })
                .then(success, error);
        } else {
            $ionicLoading.hide();
            if (localStorageService.get('user_transaction') !== undefined) {
                ////console.log("data gotten from localStorage");
                $scope.transactions = JSON.parse(localStorageService.get('user_transaction'));

            }
        }

        // Set Header
        // $scope.$parent.showHeader();
        // $scope.$parent.clearFabs();
        // $scope.isExpanded = false;
        // $scope.$parent.setExpanded(false);
        // $scope.$parent.setHeaderFab(false);
        // Set Motion
        // $timeout(function() {
        //     ionicMaterialMotion.slideUp({
        //         selector: '.slide-up'
        //     });
        // }, 300);

        $timeout(function () {
            ionicMaterialMotion.fadeSlideInRight({
                startVelocity: 3000
            });
        }, 700);

        // Set Ink
        ionicMaterialInk.displayEffect();

    })

.controller('referAndEarn',['localStorageService','$scope','$ionicModal','$ionicPopup', '$timeout','referService','AuthService','$ionicLoading', 'MerchantService',
function(localStorageService,$scope, $ionicModal,$ionicPopup, $timeout,referService,AuthService,$ionicLoading,MerchantService){
   $scope.wallets = [];
   $scope.wallets = JSON.parse(localStorageService.get('submerchantData'));
   $scope.ser = AuthService.getSerialNoToken()
   //MerchantService.MerchantList({}).then(success1, error);
   //$scope.userData = AuthService.getLoggedInUserToken()
    $scope.userData = JSON.parse(localStorageService.get('user_log'))
   $scope.userNo = JSON.parse(localStorageService.get('user_no'))
   console.log($scope.wallets);
    $scope.checkedMarchant = [];
    $scope.toggleCheck = function (wallets) {
        if ($scope.checkedMarchant.indexOf(wallets) === -1) {
            $scope.checkedMarchant.push(wallets);
        } else {
            $scope.checkedMarchant.splice($scope.checkedMarchant.indexOf(wallets), 1);
        }
   console.log($scope.checkedMarchant);
    };
    $scope.closeModal= function(){
         $('#closemodal').modal('hide');
    }
    $scope.refer = function () {
    var referPopup = $ionicPopup.show({
                    templateUrl: 'views/common/merchantSelect.html',
                    title: 'Referral Form',
                    buttons: [
                        { text: 'cancel' }
                    ]
                });
     };

      var error = function (error) {
                console.log("error");
                console.log(error);
                $ionicLoading.hide();

                //$scope.transactions = JSON.parse(localStorageService.get('user_transaction'));
                //console.log($scope.transactions);
                //$scope.countTransaction = Object.keys($scope.transactions).length;
                //getTransById();
                ////console.log('trans', $scope.transactions);
            }


            var success = function (response) {
                console.log("success");
            $ionicLoading.hide();
              $scope.successmsg = response.data.message;
               var referPopup = $ionicPopup.show({
                    templateUrl: 'views/common/success.html',
                    title: 'Success',
                    scope:  $scope,
                    buttons: [
                        { text: 'Ok' }
                    ]
                });
                console.log("got here");
                console.log(response);
                //getTransById();
            }
     $scope.sendReferal = function(){  
         $ionicLoading.show({
                templateUrl: "views/common/wait.html"
            });
         //console.log($scope.checkedMarchant);
           referService.postReferal({
                senderid: $scope.ser,phoneno: $scope.referee.phone, email:  $scope.referee.email, submerchantId: $scope.checkedMarchant
            }).then(success, error);

     };
}])
    .controller('TransactionsController', ['TransactionService', 'AuthService', '$scope', '$state', '$ionicLoading',
        '$timeout', '$ionicPopup', 'localStorageService', 'InternetMonitor', '$stateParams',
        function (TransactionService, AuthService, $scope, $state, $ionicLoading,
            $timeout, $ionicPopup, localStorageService, InternetMonitor, $stateParams) {
            $ionicLoading.show({
                templateUrl: "views/common/wait.html"
            });
            $scope.transactions = [];
            $scope.transById = [];
            $scope.SubMerchantId = $stateParams.subMerchantId;
            $scope.transType = $stateParams.transType;
            $scope.Holder = $stateParams.submerchantName;
            ////console.log($scope.SubMerchantId);


            var error = function (error) {
                $ionicLoading.hide();

                $scope.transactions = JSON.parse(localStorageService.get('user_transaction'));
                //console.log($scope.transactions);
                $scope.countTransaction = Object.keys($scope.transactions).length;
                getTransById();
                ////console.log('trans', $scope.transactions);
            }


            var success = function (response) {
                $ionicLoading.hide();
                $scope.transactions = response.data.transactions;
                $scope.countTransaction = Object.keys($scope.transactions).length
                localStorageService.remove('user_transaction');
                localStorageService.set('user_transaction', JSON.stringify(response.data.transactions));
                //console.log(response);
                getTransById();
            }
            function getTransById() {
                $scope.transById = [];
                            /* //console.log($scope.transactions);
                //console.log($scope.SubMerchantId);
                //console.log($scope.transType);*/
                for (var i = 0; i < $scope.countTransaction; i++) {
                    if (($scope.transactions[i].submerchantId == $scope.SubMerchantId) && ($scope.transactions[i].transType == $scope.transType)) {

                        $scope.transById.push($scope.transactions[i]);
                        //console.log($scope.transactions[i]);
                    }
                }
                //console.log($scope.transById);
            }
            function getMeData() {
                TransactionService.getUserTransaction({
                    id: AuthService.getLoggedInUserToken(),
                    dbname: AuthService.getMerchantDbToken(), serialnum: AuthService.getSerialNoToken()
                })
                    .then(success, error);
            }

            setInterval(function () {
                getMeData();
            }, 100000
            );
            TransactionService.getUserTransaction({
                id: AuthService.getLoggedInUserToken(),
                dbname: AuthService.getMerchantDbToken(), serialnum: AuthService.getSerialNoToken()
            }).then(success, error);

        }])

    .controller('VoucherSetupController', ['VoucherSetupService', 'AuthService', '$scope', '$state', '$ionicLoading',
        '$timeout', '$ionicPopup', 'InternetMonitor', 'localStorageService', '$stateParams', 'Constants',
        function (VoucherSetupService, AuthService, $scope, $state, $ionicLoading,
            $timeout, $ionicPopup, InternetMonitor, localStorageService, $stateParams, Constants) {
            $ionicLoading.show({
                templateUrl: "views/common/wait.html"
            });
            //$scope.userLevel = 1000;
            $scope.vouchers = [];
            $scope.Holder = $stateParams.submerchantName;
            $scope.url = Constants.API.imgurl;
            $scope.userLevel = localStorageService.get('userLevel');
            if ($scope.userLevel == "Silver") {
                $scope.LevelColor = "silver";
            }
            if ($scope.userLevel == "Gold") {
                $scope.LevelColor = "gold";
            }
            if ($scope.userLevel == "Diamond") {
                $scope.LevelColor = "rgba(198, 244, 255, 0.94)";
            }
            if ($scope.userLevel == "Platinum") {
                $scope.LevelColor = "E5E4E2";
            }
            var error = function (error) {
                $ionicLoading.hide();

                $ionicLoading.hide();
                if (localStorageService.get('user_voucher') !== undefined) {
                    ////console.log("data gotten from localStorage");
                    $scope.vouchers = JSON.parse(localStorageService.get('user_voucher'));

                }
                else {
                    var errorPopup = $ionicPopup.show({
                        templateUrl: 'views/common/erorr.html',
                        title: 'Error',
                        scope: $scope,
                        buttons: [
                            { text: 'Ok' }
                        ]
                    });


                    $timeout(function () {
                        errorPopup.close(); //close the popup after 3 seconds for some reason
                    }, 1000);
                }
            }

            var success = function (response) {
                $ionicLoading.hide();
                //console.log('response', response);
                $scope.vouc = response.data;

                localStorageService.remove('userLevel');
                localStorageService.set('userLevel', $scope.vouc[0].tierName);
                $scope.userLevel = $scope.vouc[0].tierName;
                $scope.vouchers = validateVoucher($scope.vouc);
                localStorageService.remove('user_voucher');
                localStorageService.set('user_voucher', JSON.stringify($scope.vouchers));
                if ($scope.vouchers[0] == null) {
                    $scope.showDefault = true;
                }
                else   
                $scope.showDefault = false;     
                ////console.log('scope.userLevel', $scope.userLevel);

            }
            var validateVoucher = function (voucher) {
                //console.log(voucher);
                var counter = voucher.length
                $scope.vouch = [];
                for (var i = 0; i < counter; i++) {
                    var status = voucher[i].status;
                    var expiry = voucher[i].expiry;
                    if (status == "A") {
                        if (expiry == "0") {
                            $scope.vouch.push(voucher[i])
                        }
                        ////console.log(voucher.splice(i, 1)); 
                        ////console.log(voucher[i]); 
                    }
                }
                //console.log("return", $scope.vouch);
                return $scope.vouch;
            }

            function getMeData() {
                VoucherSetupService.getVoucherData({
                    id: AuthService.getLoggedInUserToken(),
                    dbname: AuthService.getMerchantDbToken(), serialnum: AuthService.getSerialNoToken()
                }).then(success, error);
            }
            setInterval(function () {
                getMeData();
            }, 4000
            );
            VoucherSetupService.getVoucherData({
                id: AuthService.getLoggedInUserToken(),
                dbname: AuthService.getMerchantDbToken(), serialnum: AuthService.getSerialNoToken()
            }).then(success, error);

        }])

    .controller('WalletController', ['WalletService', 'AuthService', '$scope', '$state', '$ionicLoading',
        '$timeout', '$ionicPopup', 'localStorageService', '$interval', '$ionicHistory', 'Constants',
        function (WalletService, AuthService, $scope, $state, $ionicLoading, $timeout, $ionicPopup, localStorageService, $interval, $ionicHistory, Constants) {
            $ionicLoading.show({
                templateUrl: "views/common/wait.html"
            });
            // variable declaration
            $scope.totalRedemption = 0;
            $scope.totalAccurals = 0;
            $scope.totalPoints = 0;
            $scope.wallets = [];
            $scope.url = Constants.API.imgurl;
            var error = function (error) {
                $ionicLoading.hide();

                $scope.wallets = localStorageService.get('wallets')
                // //console.log($scope.wallets);
                $scope.countTransaction = Object.keys($scope.wallets).length
                $ionicLoading.hide();
                $scope.balances = localStorageService.get('balance')
                getTotalAccurals();
                getTotalRedemption();
                getTotalPoint();
            }

            var success = function (response) {
                $ionicLoading.hide();
                // $scope.vouchers=JSON.parse(localStorageService.get('user_voucher'));
                //$scope.userLevel = $scope.vouchers[0].tierName;
                $scope.wallets = response.data.wallet;
                //console.log('wallets', $scope.wallets);
                localStorageService.set('wallets', $scope.wallets);
                $scope.countTransaction = Object.keys($scope.wallets).length
                $scope.balances = response.data.bal;
                localStorageService.set('balance', $scope.balances);
                getTotalAccurals();
                getTotalRedemption();
                getTotalPoint();

            }

            function getTotalAccurals() {
                $scope.totalAccurals = 0;
                for (var i = 0; i < $scope.countTransaction; i++) {
                    $scope.totalAccurals = parseInt($scope.wallets[i].accruedpoints) + $scope.totalAccurals;

                }
                //  //console.log('totalAccurals', $scope.totalAccurals );

            }

            function getTotalRedemption() {
                $scope.totalRedemption = 0.00;
                for (var i = 0; i < $scope.countTransaction; i++) {
                    //console.log('' + i, $scope.wallets[i].redeemableamt);
                    $scope.totalRedemption = parseFloat($scope.wallets[i].redeemableamt) + $scope.totalRedemption;

                }
                // //console.log('totalRedemption', $scope.totalRedemption );

            }
            function getTotalPoint() {
                $scope.totalPoints = 0;
                for (var i = 0; i < $scope.countTransaction; i++) {
                    $scope.totalPoints = parseFloat($scope.wallets[i].tierpoint) + $scope.totalPoints;

                }
                //console.log('totalPoints', $scope.totalPoints);

            }
            function getMeData() {
                WalletService.getUserBalance({ id: AuthService.getLoggedInUserToken(), dbname: AuthService.getMerchantDbToken(), serialnum: AuthService.getSerialNoToken() })
                    .then(success, error);
            }

            setInterval(function () {
                getMeData();
            }, 10000
            );
            WalletService.getUserBalance({ id: AuthService.getLoggedInUserToken(), dbname: AuthService.getMerchantDbToken(), serialnum: AuthService.getSerialNoToken() })
                .then(success, error);
            // $interval( WalletService.getUserBalance({id:AuthService.getLoggedInUserToken(),dbname:AuthService.getMerchantDbToken(), serialnum:AuthService.getSerialNoToken()})
            //           , 1000).then(success,error);

        }])

    .controller("LinegraphCtrl", ['AuthService', 'GraphService', '$scope', '$ionicLoading',
        'InternetMonitor', 'localStorageService',
        function (AuthService, GraphService, $scope, $ionicLoading, InternetMonitor, localStorageService) {





            $scope.labels = ["03 Dec", "04 Dec", "05 Dec",
                "06 Dec", "07 Dec", "08 Dec", "09 Dec", "10 Dec", "11 Dec", "12 Dec", "13 Dec", "14 Dec", "15 Dec", "16 Dec"];
            $scope.series = ['Accruals', 'Redemption'];
            $scope.colours = [{
                fillColor: 'rgba(47, 132, 71, 0.8)',
                strokeColor: 'rgba(47, 132, 71, 0.8)',
                highlightFill: 'rgba(47, 132, 71, 0.8)', 
                highlightStroke: 'rgba(47, 132, 71, 0.8)'
            }];
            $scope.data = [
                [65, 0, 80, 81, 56, 55, 40, 35, 67, 78, 33, 24, 12, 45],
                [28, 48, 40, 19, 86, 27, 90, 55, 23, 52, 78, 23, 21, 102]
            ];
            ////console.log($scope.data);
        }])
    .controller('AuthRegController', ['AuthService', '$scope', '$ionicLoading', '$state', '$ionicPopup', '$timeout', 'Constants', '$ionicHistory',
        function (AuthService, $scope, $ionicLoading, $state, $ionicPopup, $timeout, Constants, $ionicHistory) {

            $scope.user = {};


            var registerData = { firstname: $scope.user.firstname, phoneno: $scope.user.phoneno, mobilenetwork: $scope.user.mobilenetwork, lastname: $scope.user.lastname, email: $scope.user.email, password: $scope.user.password };

            //console.log(registerData);
            var error = function (response) {
                //console.log(response);
                $ionicLoading.hide();
                console.log(response.data);
                $scope.error = 'The internet is disconnected on your device.';

                var errorPopup = $ionicPopup.show({
                    templateUrl: 'views/common/erorr.html',
                    title: 'Error',
                    scope: $scope,
                    buttons: [
                        { text: 'Ok' }
                    ]
                });


                $timeout(function () {
                    errorPopup.close(); //close the popup after 3 seconds for some reason
                }, 4000);
            }


            var success = function (response) {
                //console.log(response);
                $ionicLoading.hide();
                if (response.data.error == true) {

                    $scope.error = response.data.message;
                    var successPopup = $ionicPopup.show({
                        templateUrl: 'views/common/erorr.html',
                        title: 'Info',
                        scope: $scope,
                        buttons: [
                            { text: 'Ok' }
                        ]
                    });

                    $timeout(function () {
                        successPopup.close();
                    }, 10000);
                }

                if (response.data.error == false) {

                    $scope.error = response.data.message;
                    var successPopup = $ionicPopup.show({
                        templateUrl: 'views/common/erorr.html',
                        title: 'Info',
                        scope: $scope,
                        buttons: [
                            { text: 'Ok' }
                        ]
                    });

                    $timeout(function () {
                        successPopup.close();
                    }, 10000);

                    window.localStorage.clear();

                    AuthService.loginUser({ userno: $scope.user.phoneno, password: $scope.user.password })
                        .then(function (response) {
                            //console.log(response);
                            $ionicLoading.hide();
                            AuthService.setLoginUserIdToken(response.data.id);
                            AuthService.setMerchantDbToken(response.data.merchantDb);
                            AuthService.setSerialNoToken(response.data.serialNo);
                            //console.log(response.data);
                            //console.log(AuthService.getSerialNoToken());
                            $ionicHistory.clearCache().then(function () { $state.go('app.listing', {}, { reload: true }) })

                        }, error);
                    // $state.go("login");

                    //var login = 
                }
            }
            $scope.register = function () {
                //console.log($scope.user.phoneno);
                $ionicLoading.show({
                    templateUrl: "views/common/wait.html"
                });
                AuthService.registerApplicant({ firstname: $scope.user.firstname, lastname: $scope.user.lastname, phoneno: $scope.user.phoneno, mobilenetwork: $scope.user.mobilenetwork, email: $scope.user.email, password: $scope.user.password, merchantId: Constants.API.merchantIDToken })
                    .then(success, error);
            }

        }])

    .controller("LinegraphCtrl", ['AuthService', 'GraphService', '$scope', '$ionicLoading',
        'InternetMonitor', 'localStorageService',
        function (AuthService, GraphService, $scope, $ionicLoading, InternetMonitor, localStorageService) {





            $scope.labels = ["03 Dec", "04 Dec", "05 Dec",
                "06 Dec", "07 Dec", "08 Dec", "09 Dec", "10 Dec", "11 Dec", "12 Dec", "13 Dec", "14 Dec", "15 Dec", "16 Dec"];
            $scope.series = ['Accruals', 'Redemption'];
            $scope.colours = [{
                fillColor: 'rgba(47, 132, 71, 0.8)',
                strokeColor: 'rgba(47, 132, 71, 0.8)',
                highlightFill: 'rgba(47, 132, 71, 0.8)',
                highlightStroke: 'rgba(47, 132, 71, 0.8)'
            }];
            $scope.data = [
                [65, 0, 80, 81, 56, 55, 40, 35, 67, 78, 33, 24, 12, 45],
                [28, 48, 40, 19, 86, 27, 90, 55, 23, 52, 78, 23, 21, 102]
            ];
            ////console.log($scope.data);
        }])
    .controller("VoucherDataController", ['VoucherDataService', 'AuthService', 'GraphService', '$scope', '$ionicLoading',
        'InternetMonitor', 'localStorageService', '$ionicPopup',
        function (VoucherDataService, AuthService, GraphService, $scope, $ionicLoading, InternetMonitor, localStorageService, $ionicPopup) {
            $ionicLoading.show({
                templateUrl: "views/common/wait.html"
            });
            $scope.voucherData = [];
            //$scope.Holder =  $stateParams.submerchantName;

            var error = function (error) {
                $ionicLoading.hide();

                $scope.error = error == null ? error.data.statusText : 'The internet is disconnected on your device.';
                $scope.title = error == null ? "Invalid Login" : 'Internet Disconnected';
                var errorPopup = $ionicPopup.show({
                    templateUrl: 'views/common/erorr.html',
                    title: $scope.title,
                    scope: $scope,
                    buttons: [
                        { text: 'Ok' }
                    ]
                });


                $timeout(function () {
                    errorPopup.close(); //close the popup after 3 seconds for some reason
                }, 1000);
            }


            var success = function (response) {
                $ionicLoading.hide();
                // $scope.balances=response.data;
                $scope.voucherData = response.data.voucher;
                //localStorageService.remove('user_voucher');
                //localStorageService.set('user_voucher',JSON.stringify(response.data));
                ////console.log($scope.voucherData);

            }

            function getMeData() {
                VoucherDataService.getVoucherData({ dbname: AuthService.getMerchantDbToken(), serialnum: AuthService.getSerialNoToken() }).then(success, error);

            }

            setInterval(function () {
                getMeData();
            }, 10000
            );


            // if(InternetMonitor.isOnline()){
            VoucherDataService.getVoucherData({ dbname: AuthService.getMerchantDbToken(), serialnum: AuthService.getSerialNoToken() }).then(success, error);

            // }else{

            // }
            //console.log($scope.voucherData);
            ////console.log($scope.data);
        }])

    .controller('ProfileController', ['AuthService', '$scope', '$ionicLoading',
        '$timeout', '$ionicPopup', '$ionicModal', '$ionicPlatform', 'InternetMonitor',
        'localStorageService', 'ionicMaterialMotion', 'ionicMaterialInk',
        function (AuthService, $scope, $ionicLoading, $timeout, $ionicPopup,
            $ionicModal, $ionicPlatform, InternetMonitor, localStorageService,
            ionicMaterialMotion, ionicMaterialInk) {
            //initial load while we get user data   
            $ionicLoading.show({
                templateUrl: "views/common/wait.html"
            });

            $scope.user = {};
            //set user data from local storage
            $scope.user = JSON.parse(localStorageService.get('user_profile'));

            //error handling if we are unable to get user data from source
            var error = function (error) {
                $ionicLoading.hide();

                if (localStorageService.get('user_profile') !== undefined) {
                    $scope.user = JSON.parse(localStorageService.get('user_profile'));
                }
                else {
                    $state.go('login');
                }
                //console.log($scope.user);
                //End error Function
            }

            // function to handle successful retrieval from database
            var loadsuccess = function (response) {
                $ionicLoading.hide();

                $scope.user = response.data.user;

                //console.log('ProfileData', $scope.user);
                if (localStorageService.get('user_profile') !== undefined) {
                    localStorageService.remove('user_profile');
                    localStorageService.set('user_profile', JSON.stringify(response.data.user));
                    $scope.user = JSON.parse(localStorageService.get('user_profile'));
                }
            };//load Success function

            var updatesuccess = function (response) {
                $ionicLoading.hide();
                if (response.data.error == true) {
                    $scope.error = response.data.message;

                    var errorPopup = $ionicPopup.show({
                        templateUrl: 'views/common/erorr.html',
                        title: 'Error',
                        scope: $scope,
                        buttons: [
                            { text: 'Ok' }
                        ]
                    });
                    $timeout(function () { errorPopup.close(); }, 4000);

                }
                else {
                    getMeData();
                    $scope.successmsg = "Your profile has been updated";

                    var successPopup = $ionicPopup.show({
                        templateUrl: 'views/common/success.html',
                        title: 'Information',
                        scope: $scope,
                        buttons: [
                            { text: 'Ok' }
                        ]
                    });
                    $timeout(function () { successPopup.close(); }, 4000);
                        if (localStorageService.get('user_profile') !== undefined) {
                        $scope.user = JSON.parse(localStorageService.get('user_profile'));
                    }
                }

            };

            AuthService.getUserProfile(AuthService.getLoggedInUserToken()).then(loadsuccess, error);

            function getMeData() {
                AuthService.getUserProfile(AuthService.getLoggedInUserToken()).then(loadsuccess, error);
            }

            //  setInterval(function () {
            //         $scope.user = JSON.parse(localStorageService.get('user_profile'));
            //  }, 8000
            //  );

            $scope.updateProfile = function () {
                var userPhone;
                var intialPhone = $scope.user.phone;
                if (intialPhone == undefined) {
                    userPhone = " ";
                } else {
                    userPhone = intialPhone;
                }

                var sk = $scope.user.skill;
                var skill;

                if (sk == undefined) {
                    skill = '';
                } else {
                    skill = sk;
                }
                var address;
                var Initialstreet = $scope.user.street1;
                if (Initialstreet == undefined) {
                    address = " ";
                } else {
                    address = Initialstreet;
                }

                var mobilenetwork;
                var Initialmobile = $scope.user.mobilenetwork;
                if (Initialmobile == undefined) {
                    mobilenetwork = " ";
                } else {
                    mobilenetwork = Initialmobile;
                }

                var ski = $scope.user.userId;
                var initialUID;

                if (ski == undefined) {
                    initialUID = '';
                } else {
                    initialUID = ski;
                }
                $ionicLoading.show({
                    templateUrl: "views/common/wait.html"
                });
                AuthService.updateUserProfile({
                    firstname: $scope.user.firstname,
                    othername: $scope.user.othername,
                    lastname: $scope.user.lastname,
                    mobilenetwork: mobilenetwork,
                    UserId: initialUID,
                    id: AuthService.getLoggedInUserToken(),
                    address: address,
                    
                }).then(updatesuccess, error);
            } //End updateprofile Function

        }])



       
  
.controller('buyAirtimeCtrl', ['$scope', '$stateParams', '$ionicLoading', '$state', '$ionicPopup', '$timeout', 'Constants', '$ionicHistory', // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams, $ionicLoading, $state, $ionicPopup, $timeout, Constants, $ionicHistory) {


}])
   
.controller('chooseNetworkCtrl', ['$scope', '$stateParams',  '$ionicLoading', '$state', '$ionicPopup', '$timeout',  'Constants', '$ionicHistory',
function ($scope, $stateParams, $ionicLoading, $state, $ionicPopup, $timeout, Constants, $ionicHistory) {


}])
.controller('airtimecategoryCtrl', ['$scope', '$stateParams',  '$ionicLoading', '$state', '$ionicPopup', '$timeout',  'Constants', '$ionicHistory',
function ($scope, $stateParams, $ionicLoading, $state, $ionicPopup, $timeout, Constants, $ionicHistory) {


}])
.controller('airtimeformCtrl', ['localStorageService', '$scope', '$stateParams', '$ionicLoading', '$state', '$ionicPopup', '$timeout', '$timeout', 'Constants', '$ionicHistory',
function (localStorageService, $scope, $stateParams, $ionicLoading, $state, $ionicPopup, $timeout, Constants, $ionicHistory) {
    
    $scope.user = JSON.parse(localStorageService.get('user_profile'));

   

}])

.controller('airtimeotherformCtrl', ['localStorageService', '$scope', '$stateParams', '$ionicLoading', '$state', '$ionicPopup', '$timeout', '$timeout', 'Constants', '$ionicHistory',
function (localStorageService, $scope, $stateParams, $ionicLoading, $state, $ionicPopup, $timeout, Constants, $ionicHistory) {
    
    $scope.user = JSON.parse(localStorageService.get('user_profile'));

   
}])


.controller('airtimesummaryCtrl', ['localStorageService', '$scope', '$stateParams', '$ionicLoading', '$state', '$ionicPopup', '$timeout', 'Constants', '$ionicHistory',
function (localStorageService, $scope, $stateParams, $ionicLoading, $state, $ionicPopup, $timeout, Constants, $ionicHistory) {
    $scope.user = JSON.parse(localStorageService.get('user_profile'));
    console.log($scope.user.amount);
    
}])
   
.controller('mTNVTUCtrl', ['$scope', '$stateParams',  '$ionicLoading', '$state', '$ionicPopup', '$timeout', 'Constants', '$ionicHistory',
function ($scope, $stateParams, $ionicLoading, $state, $ionicPopup, $timeout, Constants, $ionicHistory) {


}])
   
.controller('gloVTUCtrl', ['$scope', '$stateParams', '$ionicLoading', '$state', '$ionicPopup', '$timeout', 'Constants', '$ionicHistory',
function ($scope, $stateParams, $ionicLoading, $state, $ionicPopup, $timeout, Constants, $ionicHistory) {


}])
   
.controller('mobileVTUCtrl', ['$scope', '$stateParams', '$ionicLoading', '$state', '$ionicPopup', '$timeout', 'Constants', '$ionicHistory',
function ($scope, $stateParams, $ionicLoading, $state, $ionicPopup, $timeout, Constants, $ionicHistory) {


}])
   
.controller('airtelVTUCtrl', ['$scope', '$stateParams', '$ionicLoading', '$state', '$ionicPopup', '$timeout', 'Constants', '$ionicHistory',
function ($scope, $stateParams, $ionicLoading, $state, $ionicPopup, $timeout, Constants, $ionicHistory) {


}])
   
.controller('mTN100Ctrl', ['localStorageService', '$scope', '$stateParams', '$ionicLoading', '$state', '$ionicPopup', '$timeout', 'Constants', '$ionicHistory',
function (localStorageService, $scope, $stateParams, $ionicLoading, $state, $ionicPopup, $timeout, Constants, $ionicHistory) {
    $scope.user = JSON.parse(localStorageService.get('user_profile'));
    $scope.amount = "100";

    

}])

   
.controller('mTN200Ctrl', ['localStorageService', '$scope', '$stateParams', '$ionicLoading', '$state', '$ionicPopup', '$timeout', 'Constants', '$ionicHistory',
function (localStorageService, $scope, $stateParams, $ionicLoading, $state, $ionicPopup, $timeout, Constants, $ionicHistory) {
    $scope.user = JSON.parse(localStorageService.get('user_profile'));
    $scope.amount = "200";

    

}])
   
.controller('mTN400Ctrl', ['localStorageService', '$scope', '$stateParams', '$ionicLoading', '$state', '$ionicPopup', '$timeout', '$timeout', 'Constants', '$ionicHistory',
function (localStorageService, $scope, $stateParams, $ionicLoading, $state, $ionicPopup, $timeout, Constants, $ionicHistory) {

    
}])
   
.controller('mTN750Ctrl', ['localStorageService', '$scope', '$stateParams', '$ionicLoading', '$state', '$ionicPopup', '$timeout', '$timeout', 'Constants', '$ionicHistory',
function (localStorageService, $scope, $stateParams, $ionicLoading, $state, $ionicPopup, $timeout, Constants, $ionicHistory) {

    $scope.user = JSON.parse(localStorageService.get('user_profile'));
    $scope.amount = "750";
    console.log($scope.user)

    
}])
   
.controller('mTN1000Ctrl', ['localStorageService', '$scope', '$stateParams', '$ionicLoading', '$state', '$ionicPopup', '$timeout', '$timeout', 'Constants', '$ionicHistory',
function (localStorageService, $scope, $stateParams, $ionicLoading, $state, $ionicPopup, $timeout, Constants, $ionicHistory) {

    $scope.user = JSON.parse(localStorageService.get('user_profile'));
    $scope.amount = "1000";

    
}])
   
.controller('mTN1500Ctrl', ['localStorageService', '$scope', '$stateParams', '$ionicLoading', '$state', '$ionicPopup', '$timeout', '$timeout', 'Constants', '$ionicHistory',
function (localStorageService, $scope, $stateParams, $ionicLoading, $state, $ionicPopup, $timeout, Constants, $ionicHistory) {
    
    $scope.user = JSON.parse(localStorageService.get('user_profile'));
    $scope.amount = "1500";
    

}])
   
.controller('mTN2000Ctrl', ['AuthService', 'airtimeService', 'localStorageService', '$scope', '$stateParams', '$ionicLoading', '$state', '$ionicPopup', '$timeout', '$timeout', 'Constants', '$ionicHistory',
function ($AuthService, $airtimeService, localStorageService, $scope, $stateParams, $ionicLoading, $state, $ionicPopup, $timeout, Constants, $ionicHistory) {
    
    $scope.user = JSON.parse(localStorageService.get('user_profile'));
    $scope.amount = "2000";

    
}])
.controller('mTN3000Ctrl', ['airtimeService', 'AuthService', '$scope', '$stateParams', '$ionicLoading', '$state',
'$timeout', '$ionicPopup', '$ionicModal', '$ionicPlatform', 'InternetMonitor',
'localStorageService', 'ionicMaterialMotion', 'ionicMaterialInk', 'Constants', '$ionicHistory',
function (airtimeService, AuthService, $scope, $ionicLoading, $timeout, $ionicPopup,
    $ionicModal, $ionicPlatform, InternetMonitor, localStorageService,
    ionicMaterialMotion, ionicMaterialInk, $stateParams, $state, $ionicPopup, $timeout, Constants, $ionicHistory) {
                
        $scope.user = JSON.parse(localStorageService.get('user_profile'));
        $scope.amount = {};
       
        
}])
   
.controller('mTNTopupCtrl', ['airtimeService', 'AuthService', '$scope', '$stateParams', '$ionicLoading', '$state',
'$timeout', '$ionicPopup', '$ionicModal', '$ionicPlatform', 'InternetMonitor',
'localStorageService', 'ionicMaterialMotion', 'ionicMaterialInk', 'Constants', '$ionicHistory',
function (airtimeService, AuthService, $scope, $ionicLoading, $ionicPopup,
    $ionicModal, $ionicPlatform, InternetMonitor, localStorageService,
    ionicMaterialMotion, ionicMaterialInk, $stateParams, $state, $ionicPopup, $timeout, Constants, $ionicHistory) {
    
        $scope.user = JSON.parse(localStorageService.get('user_profile'));
          
}])
   
.controller('glo100Ctrl', ['localStorageService', '$scope', '$stateParams', '$ionicLoading', '$state', '$ionicPopup', '$timeout', 'Constants', '$ionicHistory',
function (localStorageService, $scope, $stateParams, $ionicLoading, $state, $ionicPopup, $timeout, Constants, $ionicHistory) {
    $scope.user = JSON.parse(localStorageService.get('user_profile'));
    
    

}])
   
.controller('glo150Ctrl', ['localStorageService', '$scope', '$stateParams', '$ionicLoading', '$state', '$ionicPopup', '$timeout', 'Constants', '$ionicHistory',
function (localStorageService, $scope, $stateParams, $ionicLoading, $state, $ionicPopup, $timeout, Constants, $ionicHistory) {
    $scope.user = JSON.parse(localStorageService.get('user_profile'));

   

}])
   
.controller('glo200Ctrl', ['localStorageService', '$scope', '$stateParams', '$ionicLoading', '$state', '$ionicPopup', '$timeout', 'Constants', '$ionicHistory',
function (localStorageService, $scope, $stateParams, $ionicLoading, $state, $ionicPopup, $timeout, Constants, $ionicHistory) {
    $scope.user = JSON.parse(localStorageService.get('user_profile'));

   

}])
   
.controller('glo300Ctrl', ['localStorageService', '$scope', '$stateParams', '$ionicLoading', '$state', '$ionicPopup', '$timeout', 'Constants', '$ionicHistory',
function (localStorageService, $scope, $stateParams, $ionicLoading, $state, $ionicPopup, $timeout, Constants, $ionicHistory) {
    $scope.user = JSON.parse(localStorageService.get('user_profile'));

    

}])
   
.controller('glo500Ctrl', ['localStorageService', '$scope', '$stateParams', '$ionicLoading', '$state', '$ionicPopup', '$timeout', 'Constants', '$ionicHistory',
function (localStorageService, $scope, $stateParams, $ionicLoading, $state, $ionicPopup, $timeout, Constants, $ionicHistory) {
    $scope.user = JSON.parse(localStorageService.get('user_profile'));

   

}])
   
.controller('glo1000Ctrl', ['localStorageService', '$scope', '$stateParams', '$ionicLoading', '$state', '$ionicPopup', '$timeout', 'Constants', '$ionicHistory',
function (localStorageService, $scope, $stateParams, $ionicLoading, $state, $ionicPopup, $timeout, Constants, $ionicHistory) {
    $scope.user = JSON.parse(localStorageService.get('user_profile'));

    

}])
   
.controller('glo3000Ctrl', ['localStorageService', '$scope', '$stateParams', '$ionicLoading', '$state', '$ionicPopup', '$timeout', 'Constants', '$ionicHistory',
function (localStorageService, $scope, $stateParams, $ionicLoading, $state, $ionicPopup, $timeout, Constants, $ionicHistory) {
    $scope.user = JSON.parse(localStorageService.get('user_profile'));

   

}])
   
.controller('gloTopupCtrl', ['localStorageService', '$scope', '$stateParams', '$ionicLoading', '$state', '$ionicPopup', '$timeout', 'Constants', '$ionicHistory',
function (localStorageService, $scope, $stateParams, $ionicLoading, $state, $ionicPopup, $timeout, Constants, $ionicHistory) {
    $scope.user = JSON.parse(localStorageService.get('user_profile'));

    

}])
   
.controller('mobile100Ctrl', ['localStorageService', '$scope', '$stateParams', '$ionicLoading', '$state', '$ionicPopup', '$timeout', 'Constants', '$ionicHistory',
function (localStorageService, $scope, $stateParams, $ionicLoading, $state, $ionicPopup, $timeout, Constants, $ionicHistory) {
    $scope.user = JSON.parse(localStorageService.get('user_profile'));

    

}])
   
.controller('mobile200Ctrl', ['localStorageService', '$scope', '$stateParams', '$ionicLoading', '$state', '$ionicPopup', '$timeout', 'Constants', '$ionicHistory',
function (localStorageService, $scope, $stateParams, $ionicLoading, $state, $ionicPopup, $timeout, Constants, $ionicHistory) {
    $scope.user = JSON.parse(localStorageService.get('user_profile'));

   

}])
   
.controller('mobile500Ctrl', ['localStorageService', '$scope', '$stateParams', '$ionicLoading', '$state', '$ionicPopup', '$timeout', 'Constants', '$ionicHistory',
function (localStorageService, $scope, $stateParams, $ionicLoading, $state, $ionicPopup, $timeout, Constants, $ionicHistory) {
    $scope.user = JSON.parse(localStorageService.get('user_profile'));

    

}])
   
.controller('mobile1000Ctrl', ['localStorageService', '$scope', '$stateParams', '$ionicLoading', '$state', '$ionicPopup', '$timeout', 'Constants', '$ionicHistory',
function (localStorageService, $scope, $stateParams, $ionicLoading, $state, $ionicPopup, $timeout, Constants, $ionicHistory) {
    $scope.user = JSON.parse(localStorageService.get('user_profile'));

    

}])
   
.controller('mobileTopupCtrl', ['localStorageService', '$scope', '$stateParams', '$ionicLoading', '$state', '$ionicPopup', '$timeout', 'Constants', '$ionicHistory',
function (localStorageService, $scope, $stateParams, $ionicLoading, $state, $ionicPopup, $timeout, Constants, $ionicHistory) {
    $scope.user = JSON.parse(localStorageService.get('user_profile'));

   

}])
   
.controller('airtel100Ctrl', ['localStorageService', '$scope', '$stateParams', '$ionicLoading', '$state', '$ionicPopup', '$timeout', 'Constants', '$ionicHistory',
function (localStorageService, $scope, $stateParams, $ionicLoading, $state, $ionicPopup, $timeout, Constants, $ionicHistory) {
    $scope.user = JSON.parse(localStorageService.get('user_profile'));

    
}])
   
.controller('airtel200Ctrl', ['localStorageService', '$scope', '$stateParams', '$ionicLoading', '$state', '$ionicPopup', '$timeout', 'Constants', '$ionicHistory',
function (localStorageService, $scope, $stateParams, $ionicLoading, $state, $ionicPopup, $timeout, Constants, $ionicHistory) {
    $scope.user = JSON.parse(localStorageService.get('user_profile'));

    

}])
   
.controller('airtel500Ctrl', ['localStorageService', '$scope', '$stateParams', '$ionicLoading', '$state', '$ionicPopup', '$timeout', 'Constants', '$ionicHistory',
function (localStorageService, $scope, $stateParams, $ionicLoading, $state, $ionicPopup, $timeout, Constants, $ionicHistory) {
    $scope.user = JSON.parse(localStorageService.get('user_profile'));

   

}])
   
.controller('airtel1000Ctrl', ['localStorageService', '$scope', '$stateParams', '$ionicLoading', '$state', '$ionicPopup', '$timeout', 'Constants', '$ionicHistory',
function (localStorageService, $scope, $stateParams, $ionicLoading, $state, $ionicPopup, $timeout, Constants, $ionicHistory) {
    $scope.user = JSON.parse(localStorageService.get('user_profile'));

    

}])
   
.controller('airtelTopupCtrl', ['localStorageService', '$scope', '$stateParams', '$ionicLoading', '$state', '$ionicPopup', '$timeout', 'Constants', '$ionicHistory',
function (localStorageService, $scope, $stateParams, $ionicLoading, $state, $ionicPopup, $timeout, Constants, $ionicHistory) {
    $scope.user = JSON.parse(localStorageService.get('user_profile'));

    var airtimeData = { phoneno: $scope.user.phoneno, amount: $scope.user.amount, email: $scope.user.email };
    
    $scope.airtime = function () {
        console.log($scope.user.phoneno, $scope.user.amount, $scope.user.email );
        $ionicLoading.show({
            templateUrl: "views/common/wait.html"
        });
        airtimeService.airtimeApplicant({ phoneno: $scope.user.phoneno, amount: $scope.user.amount, email: $scope.user.email })
            .then(success, error);
    }

}])

.controller('allStoresCtrl', ['localStorageService', '$scope', '$stateParams', '$ionicLoading', '$state', '$ionicPopup', '$timeout', 'Constants', '$ionicHistory',
function (localStorageService, $scope, $stateParams, $ionicLoading, $state, $ionicPopup, $timeout, Constants, $ionicHistory) {
 
}])




var avanteApp = angular.module("avanteApp")
    avanteApp.config(['$raveProvider', function ($raveProvider) {
        $raveProvider.config({
            key: "FLWPUBK-9b73ecc183146ca46f93ab76fcccd319-X",
            isProduction: false
        })
    }])

.controller("ravecontroller", [ 'localStorageService', function($scope, localStorageService,){
    // $scope.user = JSON.parse(localStorageService.get('user_profile'));
    $scope.amount = this.amount
    $scope.meta = [
        {
            metaname: "flightid",
            metavalue: "93849-MK5000"
        }
    ];
    $scope.computeReference = function() {
        let text = "Moloyal Airtime";
        let possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
        for( let i=0; i < 10; i++ )
            text += possible.charAt(Math.floor(Math.random() * possible.length));
        return text;
    };
    $scope.reference = $scope.computeReference();
    $scope.email = this.email;
    $scope.callback = function (response) {
        console.log(response);
    };
    $scope.close = function () {
        console.log("Payment closed");
    };
}])
